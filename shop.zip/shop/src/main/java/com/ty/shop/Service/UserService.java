package com.ty.shop.Service;

import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.ty.shop.Entity.User;
import com.ty.shop.Repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    

    public void saveUser(User user) {
        
        userRepository.save(user);
    }

    public boolean authenticate(String username, String password) {
        Optional<User> userOptional = userRepository.findByUsername(username);
        
        if (userOptional.isPresent()) {
            User user = userOptional.get();
            // Print details about the user found
            System.out.println("Found user: " + user.getUsername());
            System.out.println("Stored Password: " + user.getPassword());
            System.out.println("Input Password: " + password);
            
            // Compare the stored password with the input password
            if (password.equals(user.getPassword())) {
                System.out.println("Authentication successful for user: " + username);
                return true;
            } else {
                System.out.println("Invalid password for user: " + username);
                return false;
            }
        }
        System.out.println("User not found: " + username);
        return false; // User not found
    }
  }
