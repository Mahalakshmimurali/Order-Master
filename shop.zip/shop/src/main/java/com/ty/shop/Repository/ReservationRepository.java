package com.ty.shop.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.shop.Entity.Reservation;

public interface ReservationRepository extends JpaRepository<Reservation,Integer> {

}
