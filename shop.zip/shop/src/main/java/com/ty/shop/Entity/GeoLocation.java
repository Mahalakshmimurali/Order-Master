package com.ty.shop.Entity;
import jakarta.persistence.Embeddable;

@Embeddable
public class GeoLocation {
    private String name1;
    public GeoLocation() {}
	public GeoLocation(String name1) {
		super();
		this.name1 = name1;
	}

	public String getName1() {
		return name1;
	}

	public void setName1(String name1) {
		this.name1 = name1;
	}
	@Override
	public String toString() {
		return "GeoLocation [name1=" + name1 + "]";
	}
	public Object getLatitude() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getLongitude() {
		// TODO Auto-generated method stub
		return null;
	}

}
