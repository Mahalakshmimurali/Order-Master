package com.ty.shop.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ty.shop.Entity.GeoLocation;
import com.ty.shop.Entity.Order;
import com.ty.shop.Entity.Reservation;
import com.ty.shop.Entity.User;
import com.ty.shop.Service.GeocodingService;
import com.ty.shop.Service.OrderService;
import com.ty.shop.Service.ReservationService;
import com.ty.shop.Service.UserService;



@Controller
public class UserController {
	
    private static final String LOGIN = "admin/login";
    private static final String REGISTER = "admin/register";

    @Autowired
    private UserService userService;

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private OrderService orderService;
    
    @Autowired
    private GeocodingService geocodingService;
    

    @GetMapping("/register")
    public String getRegister(Model model) {
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user) {
        userService.saveUser(user);
        return "redirect:/login?success";
    }

    @GetMapping("/login")
    public String getLogin(@RequestParam(value = "error", required = false) String error,
                           @RequestParam(value = "success", required = false) String success,
                           Model model) {
        if (error != null) {
            model.addAttribute("error", "Invalid username or password.");
        }
        if (success != null) {
            model.addAttribute("success", "Registration successful! Please log in.");
        }
        return "login"; // Return the name of the login view
    }

    @PostMapping("/login")
    public String loginUser(@RequestParam("username") String username,
                            @RequestParam("password") String password) {
        // Implement your authentication logic here
        boolean isAuthenticated = userService.authenticate(username, password);

        if (isAuthenticated) {
            return "redirect:/index"; // Redirect to home after successful login
        } else {
            return "redirect:/login?error"; // Redirect back to login with error
        }
    }

    @GetMapping("/index")
    public String home1() {
        return "index";
    }

    @GetMapping("/reservation")
    public String home2() {
        return "reservation";
    }

    @GetMapping("/home")
    public String home3() {
        return "home";
    }

    @PostMapping("/reservation")
    public String saveReservation(@RequestParam("booking-form-id") int id,
                                  @RequestParam("booking-form-name") String name,
                                  @RequestParam("booking-form-phone") String phone,
                                  @RequestParam("booking-form-time") String time,
                                  @RequestParam("booking-form-date") String date,
                                  @RequestParam("booking-form-number") int numberOfPeople,
                                  @RequestParam("booking-form-message") String comment) {
        Reservation reservation = new Reservation();
        reservation.setId(id);
        reservation.setFull_name(name);
        reservation.setPhone(phone);
        reservation.setTime(time);
        reservation.setDate(date);
        reservation.setNumberofPeople(numberOfPeople);
        reservation.setComment(comment);

        reservationService.saveReservation(reservation);
        return "redirect:/success";
    }

    @GetMapping("/success")
    public String showSuccessPage() {
        return "success";
    }
    
    @GetMapping("/order")
    public String showOrderForm(Model model) {
        model.addAttribute("order", new Order());
        return "order";
    }

    @PostMapping("/order")
    public String submitOrder(@ModelAttribute Order order,
                              @RequestParam("sourceName") String sourceName,
                              @RequestParam("destinationName") String destinationName,
                              Model model) {
        GeoLocation source = new GeoLocation(sourceName);
        GeoLocation destination = new GeoLocation(destinationName);

        order.setSource(source);
        order.setDestination(destination);

        orderService.saveOrder(order);
        model.addAttribute("message", "Order placed successfully!");
        return "redirect:/order-success"; // PRG pattern
    }

    @GetMapping("/order-success")
    public String orderSuccess(Model model) {
        model.addAttribute("message", "Your order has been placed successfully!");
        return "order-success";
    }

    @GetMapping("/track-order")
    public String showTrackOrderForm() {
        return "track-order";  
    }

    @PostMapping("/track-order")
    public String trackOrder(@RequestParam("id") int id, Model model) {
        Order order = orderService.getOrderById(id);
        if (order == null) {
            model.addAttribute("error", "Order not found");
            return "track-order";
        }

        model.addAttribute("order", order);

        return "track-order-details"; 
    }

    @GetMapping("/track-order-map")
    public String showOrderMap(@RequestParam("id") int id, Model model) {
        Order order = orderService.getOrderById(id);
        if (order == null) {
            model.addAttribute("error", "Order not found");
            return "track-order";
        }

        double[] sourceCoords = geocodingService.getCoordinates(order.getSource().getName1());
        double[] destCoords = geocodingService.getCoordinates(order.getDestination().getName1());

        if (sourceCoords != null) {
            model.addAttribute("sourceLat", sourceCoords[0]);
            model.addAttribute("sourceLon", sourceCoords[1]);
        }

        if (destCoords != null) {
            model.addAttribute("destinationLat", destCoords[0]);
            model.addAttribute("destinationLon", destCoords[1]);
        }

        model.addAttribute("order", order);

        return "track-order-map"; 
    }    
    private GeoLocation simulateCurrentLocation(Order order) {
        return new GeoLocation("In Transit");
    }

    @GetMapping("/order-status")
    public String getOrderStatus(@RequestParam("id") Integer id, Model model) {
        Optional<Order> optionalOrder = orderService.getOrderById(id);
        if (optionalOrder.isPresent()) {
            model.addAttribute("order", optionalOrder.get());
            return "order-status";
        } else {
            model.addAttribute("error", "Order not found.");
            return "track-order";
        }
    }
    @PostMapping("/order-status")
    public String submitOrder(@ModelAttribute("order") Order order) {
        System.out.println("Received order: " + order);
        System.out.println("Received id: " + order.getId());
        orderService.saveOrder(order);
        
        return "redirect:/order-status?id=" + order.getId(); // Redirect to order status
    }
    @GetMapping("/order-location")
    public LocationResponse getOrderLocation(@RequestParam("id") Integer orderId) {
        double latitude = 51.515; 
        double longitude = -0.1;   
        return new LocationResponse(latitude, longitude);
    }

    public static class LocationResponse {
        private double latitude;
        private double longitude;

        public LocationResponse(double latitude, double longitude) {
            this.latitude = latitude;
            this.longitude = longitude;
        }

        public double getLatitude() {
            return latitude;
        }

        public double getLongitude() {
            return longitude;
        }
    }
    

}
