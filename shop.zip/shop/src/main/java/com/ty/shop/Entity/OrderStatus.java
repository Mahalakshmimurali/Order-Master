package com.ty.shop.Entity;

public enum OrderStatus {
    NEW,
	PENDING,
    PROCESSING,
    SHIPPED,
    DELIVERED,
    CANCELLED
}
