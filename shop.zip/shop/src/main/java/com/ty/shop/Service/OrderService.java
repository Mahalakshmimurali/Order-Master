package com.ty.shop.Service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ty.shop.Entity.Order;
import com.ty.shop.Entity.OrderStatus;
import com.ty.shop.Repository.OrderRepository;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Order saveOrder(Order order) {
    	order.setStatus(OrderStatus.PENDING);
        order.setOrderDate(LocalDateTime.now());
        return orderRepository.save(order);
    }

    public Optional<Order> getOrderById(Integer id) {
        return orderRepository.findById(id);
    }

    public void updateOrderStatus(int id, OrderStatus status) {
        Optional<Order> optionalOrder = orderRepository.findById(id);
        if (optionalOrder.isPresent()) {
            Order order = optionalOrder.get();
            order.setStatus(status);
            orderRepository.save(order);
        }
}
    public OrderStatus getOrderStatus(Integer id) {
        return orderRepository.findById(id).map(Order::getStatus).orElse(null);
    }

    public Order getOrderById(int id) {
        return orderRepository.findById(id).orElse(null);
    }
    
}
