package com.ty.shop.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.AttributeOverride;
import jakarta.persistence.AttributeOverrides;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Column;

@Entity
@Table(name = "`order`")
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private String phone;
    private String street;
    private String city;
    private String district;
    private String state;
    private String menuItem;
    private int quantity;
    private LocalDateTime orderDate;
    private String specialRequests;
    @Embedded
    private GeoLocation currentLocation;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "name1", column = @Column(name = "source_name"))
    })
    private GeoLocation source;

    @Embedded
    @AttributeOverrides({
        @AttributeOverride(name = "name1", column = @Column(name = "destination_name"))
    })
    private GeoLocation destination;

    @Enumerated(EnumType.STRING)
    private OrderStatus status = OrderStatus.PENDING;

    public Order() {
        super();
    }

    @PrePersist
    protected void onCreate() {
        this.orderDate = LocalDateTime.now();
        if (this.status == null) {
            this.status = OrderStatus.PENDING;
        }
    }

    public Order(int id, String name, String phone, String street, String city, String district, String state,
                 String menuItem, int quantity, LocalDateTime orderDate, String specialRequests, GeoLocation currentLocation,
                 GeoLocation source, GeoLocation destination, OrderStatus status) {
        super();
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.street = street;
        this.city = city;
        this.district = district;
        this.state = state;
        this.menuItem = menuItem;
        this.quantity = quantity;
        this.orderDate = orderDate;
        this.specialRequests = specialRequests;
        this.currentLocation = currentLocation;
        this.source = source;
        this.destination = destination;
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order [id=" + id + ", name=" + name + ", phone=" + phone + ", street=" + street + ", city=" + city
                + ", district=" + district + ", state=" + state + ", menuItem=" + menuItem + ", quantity=" + quantity
                + ", orderDate=" + orderDate + ", specialRequests=" + specialRequests + ", currentLocation="
                + currentLocation + ", source=" + source + ", destination=" + destination + ", status=" + status + "]";
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getMenuItem() {
        return menuItem;
    }

    public void setMenuItem(String menuItem) {
        this.menuItem = menuItem;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDateTime orderDate) {
        this.orderDate = orderDate;
    }

    public String getSpecialRequests() {
        return specialRequests;
    }

    public void setSpecialRequests(String specialRequests) {
        this.specialRequests = specialRequests;
    }

    public GeoLocation getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(GeoLocation currentLocation) {
        this.currentLocation = currentLocation;
    }

    public GeoLocation getSource() {
        return source;
    }

    public void setSource(GeoLocation source) {
        this.source = source;
    }

    public GeoLocation getDestination() {
        return destination;
    }

    public void setDestination(GeoLocation destination) {
        this.destination = destination;
    }

    public OrderStatus getStatus() {
        return status;
    }

    public void setStatus(OrderStatus status) {
        this.status = status;
    }
}
