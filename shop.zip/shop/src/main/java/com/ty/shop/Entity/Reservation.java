package com.ty.shop.Entity;

import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String full_name;
    private String phone;
    private String time;
    private String date;
    private int NumberofPeople;
    private String comment;
	public Reservation() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Reservation(int id, String full_name, String phone, String time, String date, int numberofPeople,
			String comment) {
		super();
		this.id = id;
		this.full_name = full_name;
		this.phone = phone;
		this.time = time;
		this.date = date;
		NumberofPeople = numberofPeople;
		this.comment = comment;
	}
	@Override
	public String toString() {
		return "Reservation [id=" + id + ", full_name=" + full_name + ", phone=" + phone + ", time=" + time + ", date="
				+ date + ", NumberofPeople=" + NumberofPeople + ", comment=" + comment + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFull_name() {
		return full_name;
	}
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public int getNumberofPeople() {
		return NumberofPeople;
	}
	public void setNumberofPeople(int numberofPeople) {
		NumberofPeople = numberofPeople;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
     
}

