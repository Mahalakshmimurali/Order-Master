package com.ty.shop.Service;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class GeocodingService {

    private static final String NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";

    public double[] getCoordinates(String locationName) {
        RestTemplate restTemplate = new RestTemplate();
        String uri = UriComponentsBuilder.fromHttpUrl(NOMINATIM_URL)
                .queryParam("q", locationName)
                .queryParam("format", "json")
                .queryParam("limit", 1)
                .toUriString();

        try {
            NominatimResponse[] response = restTemplate.getForObject(uri, NominatimResponse[].class);
            if (response != null && response.length > 0) {
                return new double[]{Double.parseDouble(response[0].getLat()), Double.parseDouble(response[0].getLon())};
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static class NominatimResponse {
        private String lat;
        private String lon;

        public String getLat() {
            return lat;
        }

        public void setLat(String lat) {
            this.lat = lat;
        }

        public String getLon() {
            return lon;
        }

        public void setLon(String lon) {
            this.lon = lon;
        }
    }
}
